import 'dart:convert';
import 'dart:math';
import 'lib/roux.dart' as old;
import 'package:roux/roux.dart';

void main() {
  final random = Random(519);
  final parts = ['', '.', '..', 'a','b','{a}?','{.}?','{a/}?','{/a}?','{a//b}?',r'\{a\}', ':x?',':x+',':x*','*','**','...','é',r'\*',r'\\*',r'\**','foo-:x',r':v([ab]+)',r':v((?<n>a)\k<n>)'];
  final inputs = <String>{'','/','//','/x','/x/a','/x/b','/x/b/b','/x/a/b','/x/é','/x/aa','/b','/a','/a/b','/x/b/a','/x/a/a','/x/a/b/a','/x/a/b/b','/x/foo-b', r'/x/\q'};
  int checks=0;
  void same(Object? a,Object? b,String message) {
    if(jsonEncode(a)!=jsonEncode(b))throw StateError('$message\n$a\n$b');
    checks++;
  }
  for(var k=0;k<1400;k++){
    final pattern='/x/${List.generate(1+random.nextInt(4),(_)=>parts[random.nextInt(parts.length)]).join('/')}';
    final a=old.Router<int>(), b=Router<int>();String? ea,eb;
    try{a.add(pattern,k);}catch(e){ea=e.runtimeType.toString();}
    try{b.add(pattern,k);}catch(e){eb=e.runtimeType.toString();}
    same(ea,eb,pattern);
    for(final q in inputs){
      final x=a.find(q), y=b.find(q);
      same([x?.data,x?.params,[for(final m in a.findAll(q)) [m.data,m.params]]],[y?.data,y?.params,[for(final m in b.findAll(q)) [m.data,m.params]]],'$pattern $q');
    }
    if(ea==null)same(a.remove('',pattern),b.remove('',pattern),pattern);
  }
  final a=old.Router<int>(), b=Router<int>();
  for(var k=0;k<15000;k++){
    final group=random.nextInt(24), route=random.nextInt(6);
    final m=['','GET','POST','PUT'][random.nextInt(4)];
    final base='/v/$group';
    final p=['$base/:id','$base/fixed','$base/:id(\\d+)','$base/*','$base/**:r','$base/:name'][route];
    if(random.nextBool()){a.add(p,k,method:m);b.add(p,k,method:m);}else{same(a.remove(m,p),b.remove(m,p),p);}
    final q='$base/${['42','fixed','x'][random.nextInt(3)]}', method=random.nextBool()?m:' ${m.toLowerCase()} ';
    final x=a.find(q,method:method),y=b.find(q,method:method);
    final all=random.nextBool();
    same([x?.data,x?.params,[for(final r in a.findAll(q,method:method,includeAny:all)) [r.data,r.params]]],[y?.data,y?.params,[for(final r in b.findAll(q,method:method,includeAny:all)) [r.data,r.params]]],'$k $q $method');
  }
  print('$checks modifier and mutation checks equal');
}
