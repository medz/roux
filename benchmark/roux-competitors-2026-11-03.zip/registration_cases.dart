import 'dart:convert';
import 'lib/roux.dart' as old;
import 'package:roux/roux.dart' as current;

void main() {
  final patterns = [
    '', '.', '../../', '/x/../books{/:id}?/', '/junk/../api/:id?',
    'ignored/../a//p{/.}?/', '/a/../x{/(a|b)}?', 'a{/:x}?/../b',
    r'/f/\{a\}',r'/f/\:s',r'/f/\(n\)',r'/x/:n([()]{1,3})',
    r'/:n([\]]{1})',r'/a/:id{/:x}?', r'/sub/../f/:x(\d+)?',
    r'/:x([a-z)',r'/:x(([)]', '/:9x', '/:-bad', '/a{b', '/**:9',
    '/a/:id*/b', '/:x{foo}+','/:x?(:b)', '/foo/:n{/:a}?//bar',
  ];
  final paths = ['', '/', '/books', '/books/42', '/a', '/a/p', '/a/x', '/api', '/api/3',
    '/x/a', '/x/(((', '/]', '/a/p/.', '/b','/f/{a}','/f/:s','/f/(n)', '/f/42','/foo/1/bar','/foo/1/2/bar'];
  var checks=0;
  for (final p in patterns) {
    final a=old.Router<int>(), b=current.Router<int>();
    Object? oldError,newError;
    try{a.add(p,2);}catch(e){oldError=e.runtimeType;}
    try{b.add(p,2);}catch(e){newError=e.runtimeType;}
    if(oldError!=newError) throw StateError('register $p $oldError $newError');
    for (var phase=0; phase<2; phase++) {
      for(final q in paths) {
        final x=a.find(q), y=b.find(q);
        final xs=[x?.data,x?.params,[for(final m in a.findAll(q)) [m.data,m.params]]];
        final ys=[y?.data,y?.params,[for(final m in b.findAll(q)) [m.data,m.params]]];
        if (jsonEncode(xs)!=jsonEncode(ys)) throw StateError('$phase $p $q $xs $ys');
        checks++;
      }
      if (phase==0 && oldError==null && a.remove('',p)!=b.remove('',p)) throw StateError('remove $p');
    }
  }
  print('$checks registration and removal checks equal');
}
