import 'dart:math';
import 'package:roux/roux.dart';
void main(List<String> args) {
  final n = int.parse(args.first);
  final paths=List.generate(n,(i)=>'/api/items/$i');
  for(final mode in ['ascending','descending','alternating','random','churn']){
    final order=List<int>.generate(n,(i)=>i);
    if(mode=='descending') order.sort((a,b)=>b.compareTo(a));
    if(mode=='alternating'){for(var i=0;i<n;i++){order[i]=i.isEven?i~/2:n-1-i~/2;}}
    if(mode=='random') order.shuffle(Random(124));
    final times=<double>[];
    for(var round=0;round<8;round++){
      final r=Router<int>();for(var i=0;i<n;i++){r.add(paths[i],i,method:'GET');}
      final t=Stopwatch()..start();
      for(final i in order){
        if(!r.remove('GET',paths[i]))throw StateError('failed $i');
        if(mode=='churn') r.add(paths[i],i,method:'GET');
      }
      t.stop();if(round>0)times.add(t.elapsedTicks*1e9/t.frequency/n);
      if((r.find(paths.last,method:'GET')?.data)!=(mode=='churn'?n-1:null)){throw StateError('table $mode');}
    }
    times.sort();print('$mode $n ${times[3].toStringAsFixed(1)}');
  }
}
