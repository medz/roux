import 'dart:convert';

import 'lib/roux.dart' as baseline;
import 'package:roux/roux.dart' as changed;

void main() {
  var checks = 0;
  for (final sensitive in [true, false]) {
    final old = baseline.Router<int>(caseSensitive: sensitive);
    final next = changed.Router<int>(caseSensitive: sensitive);
    final routes = <(String, String?)>[
      ('/', null), ('/**', null), ('/API/status', 'GET'),
      ('/api/:x', 'POST'), (r'/api/:v(\d+)', 'GET'), ('/api/:id', 'GET'),
      (r'/api/:x(en|fr)/:id(\d+)', null), (r'/api/:x(en)/:id', null),
      (r'/api/:x/:y(\d+)', null), ('/api/:x/:y', null), ('/api/**:rest', null),
      ('/files', 'GET'), (r'/files/\*', null), ('/files/:file.:ext', null),
      ('/files/file-*.png', 'GET'), ('/files/**:rest', null), ('/files/**', 'POST'),
      ('/books{/:id}?', null), ('/events/:rest+', 'GET'),
      ('/foo/:x?/bar', null), (r'/api/:x(\d+)/:y(\w+)/:z', 'GET'),
    ];
    void register() {
      for (var i = 0; i < routes.length; i++) {
        final (path, method) = routes[i];
        old.add(path, i, method: method);
        next.add(path, i, method: method);
      }
    }
    register();
    for (var phase = 0; phase < 3; phase++) {
      final paths = <String>{'', '/', './../', 'events', 'books'};
      for (final a in ['api', 'API', 'files', 'foo', 'events', 'books', 'missing']) {
        paths.add('/$a');
        for (final b in ['42', 'en', 'fr', 'EN', 'x.B', '%2F', 'status', '*', 'file-01.png']) {
          paths.add('/$a/$b');
          for (final c in ['7', 'abc', 'bar', '.', '..', '%2e']) {
            paths.addAll(['/$a/$b/$c', '$a//tmp/../$b/$c/', '/$a/$b/$c/tail']);
          }
        }
      }
      for (final p in paths) {
        for (final method in [null, ' get ', 'POST', 'DELETE']) {
          final a = old.find(p, method: method);
          final b = next.find(p, method: method);
          void compare(Object? x, Object? y) {
            checks++;
            if (jsonEncode(x) != jsonEncode(y)) throw StateError('$sensitive $phase $p $method: $x != $y');
          }
          compare(a == null ? null : [a.data, a.params], b == null ? null : [b.data, b.params]);
          for (final any in [true, false]) {
            compare([
              for (final m in old.findAll(p, method: method, includeAny: any)) [m.data, m.params],
            ], [
              for (final m in next.findAll(p, method: method, includeAny: any)) [m.data, m.params],
            ]);
          }
        }
      }
      for (var i = 0; i < routes.length; i += 3) {
        final (p, m) = routes[i];
        if (old.remove(m ?? '', p) != next.remove(m ?? '', p)) throw StateError('remove $p');
      }
      if (phase == 1) register();
    }
  }
  print('$checks matching results equal');
}
