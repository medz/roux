import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:isolate';
import 'benchmark/registration.dart' as b;

Future<void> main(List<String> args) async {
  final kind = args[0], n = int.parse(args[1]);
  final control = StreamIterator(stdin.transform(utf8.decoder).transform(const LineSplitter()));
  final info = await Service.getInfo();
  print('@@${jsonEncode({'uri': info.serverUri.toString(), 'isolate': Service.getIsolateId(Isolate.current)})}');
  await control.moveNext();
  final router = b.buildTable(Iterable.generate(n,(i)=>b.registration(kind,i)));
  print('@@${jsonEncode({'object':Service.getObjectId(router)})}');
  await control.moveNext();
  b.checkTable(router, kind, n);
  await control.cancel();
  exit(0);
}
