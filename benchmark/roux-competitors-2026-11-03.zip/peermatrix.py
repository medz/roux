from pathlib import Path
import sys
from measure import run
r=Path(__file__).resolve().parent
stage=sys.argv[1] if len(sys.argv)>1 else 'research'
rounds=int(sys.argv[2]) if len(sys.argv)>2 else 5
for group,exe,targets in [('pure','peers',['roux','relic','relic-nocache']),('dispatch','peers',['roux-shelf','shelf']),('nested-pure','nested',['roux','relic','relic-nocache']),('nested-dispatch','nested',['roux-shelf','shelf'])]:
 run('competitor-'+stage+'-'+group,{t:[r/(stage+'-'+exe),t] for t in targets},rounds)
