from measure import run,r,cases
import json,statistics
for kind,exe,args in [('public','lookup',[]),('hot','hot',[]),('captures','captures',[]),('extra','extra',[]),('cold','cold',[]),('remove','remove',['8192']),('tails','tails',[]),('prefixes','prefixes',[]),('peer-lookups','peers',['roux']),('dispatch','peers',['roux-shelf'])]:
 run('checkpoint-'+kind,{v:[r/(v+'-'+exe),*args] for v in ['checkpoint','research']},5)
for k in cases:
 run('checkpoint-reg-'+k,{v:[r/(v+'-registration'),k,'4096'] for v in ['checkpoint','research']},5)
for n in (16384,32768):
 run('node-wildcard-'+str(n),{v:['node',r/'node-args.cjs',r/(v+'-registration.js'),'wildcard',str(n)] for v in ['base','checkpoint','research']},5)
run('node-precise-registration',{v:['node',r/'node-clock.cjs',r/(v+'-registration.js')] for v in ['base','checkpoint','research']},7)
