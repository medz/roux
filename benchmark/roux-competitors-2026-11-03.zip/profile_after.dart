import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:isolate';
import 'benchmark/registration.dart' as b;

Future<void> main(List<String> args) async {
  final kind = args[0], n = int.parse(args[1]);
  final control = StreamIterator(stdin.transform(utf8.decoder).transform(const LineSplitter()));
  final info = await Service.getInfo();
  print('@@${jsonEncode({'uri': info.serverUri.toString(), 'isolate': Service.getIsolateId(Isolate.current)})}');
  await control.moveNext();
  final router = b.buildTable(Iterable.generate(n,(i)=>b.registration(kind,i)));
  for (var i=1;i<n;i++) {
    final e=b.registration(kind,i);
    if(!router.remove(e.method,e.pattern)) throw StateError('remove $i');
  }
  print('@@${jsonEncode({'object':Service.getObjectId(router)})}');
  await control.moveNext();
  final e=b.registration(kind,0);if(router.find(e.probe,method:e.method)?.data != 0) throw StateError('survivor');
  await control.cancel();
  exit(0);
}
