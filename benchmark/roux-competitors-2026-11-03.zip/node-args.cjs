globalThis.dartMainRunner = (main) => main(process.argv.slice(3));
require(process.argv[2]);
