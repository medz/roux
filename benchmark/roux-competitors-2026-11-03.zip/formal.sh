set -e
DART="${DART:-dart}"
export DART
cd "$(dirname "$0")"
mkdir -p results
for v in base checkpoint; do
  python3 build.py "$v" lookup registration register hot captures extra peers nested reversed cold remove tails prefixes peerbuild outlier batch
  for b in lookup registration; do "$DART" --suppress-analytics compile js -O2 --packages="$v.json" "benchmark/$b.dart" -o "$v-$b.js"; done
done
python3 build.py research lookup registration register hot captures extra peers nested reversed cold remove tails prefixes peerbuild outlier batch
for b in lookup registration; do "$DART" --suppress-analytics compile js -O2 --packages=research.json "benchmark/$b.dart" -o "research-$b.js"; done
for b in check registration_cases patterns sweep changes shapes; do "$DART" --suppress-analytics run --packages=research.json "$b.dart"; "$DART" --suppress-analytics compile js -O2 --packages=research.json "$b.dart" -o "$b.js" >/dev/null; node "$b.js"; done > results/differential.txt
python3 measure.py peers rss
python3 wide.py
python3 outlier.py
python3 peermatrix.py research 5
python3 measure.py lookup registration web jit
python3 stability.py
python3 scale.py
python3 checkpoint.py
