import 'package:relic_core/relic_core.dart' as relic;
import 'package:roux/roux.dart' as roux;
import 'package:shelf/shelf.dart' as shelf;
import 'package:shelf_router/shelf_router.dart' as sr;

typedef Parts = (String, String, String);
const path = '/nested/Report-42';
const samples = <String, Parts?>{
  path: ('Report-42', 'Report', '42'),
  '/nested/a-007': ('a-007', 'a', '007'),
  '/nested/nope': null,
  '/nested/x-3!': null,
  '/other/Report-42': null,
};

roux.Router<int> rouxRouter() =>
    roux.Router<int>()
      ..add(r'/nested/:id(([A-Za-z]+)-(\d+))', 1, method: 'GET');
Parts? readRoux(roux.RouteMatch<int>? m) =>
    m == null ? null : (m.params['id']!, m.params['0']!, m.params['1']!);
int consume(Parts? m) =>
    m == null ? -1 : m.$1.length * 31 + m.$2.length * 7 + m.$3.length;

void finish(List<double> times, int sum) {
  times.sort();
  print('nested-hot ${times[3].toStringAsFixed(1)} $sum');
}

double ns(Stopwatch sw, int n) => sw.elapsedTicks * 1e9 / sw.frequency / n;

void pure(String target) {
  late final Parts? Function(String) lookup;
  if (target == 'roux') {
    final r = rouxRouter();
    lookup = (p) => readRoux(r.find(p, method: 'GET'));
  } else {
    if (target == 'relic-nocache')
      relic.NormalizedPath.interned = const relic.NoCache();
    final r = relic.Router<int>()..get('/nested/:id', 1);
    final pattern = RegExp(r'^([A-Za-z]+)-(\d+)$', caseSensitive: false);
    lookup = (p) {
      final m = r.lookup(relic.Method.get, p);
      if (m is! relic.RouterMatch<int>) return null;
      final id = m.parameters[#id]!;
      final g = pattern.firstMatch(id);
      return g == null ? null : (id, g[1]!, g[2]!);
    };
  }
  for (final e in samples.entries) {
    if (lookup(e.key) != e.value) throw StateError('$target ${e.key}');
  }
  const n = 131072;
  final times = <double>[];
  var sum = 0;
  for (var round = 0; round < 8; round++) {
    final sw = Stopwatch()..start();
    for (var i = 0; i < n; i++) sum += consume(lookup(path));
    sw.stop();
    if (round != 0) times.add(ns(sw, n));
  }
  finish(times, sum);
}

Future<void> dispatch(String target) async {
  shelf.Response respond(Parts? p) => shelf.Response(
    p == null ? 404 : 200,
    context: {if (p != null) 'parts': p},
  );
  late final Future<shelf.Response> Function(shelf.Request) handle;
  if (target == 'shelf') {
    final r = sr.Router(notFoundHandler: (_) => respond(null));
    r.get(r'/nested/<word|[A-Za-z]+>-<number|\d+>', (shelf.Request req) {
      final params = sr.RouterParams(req).params;
      final w = params['word']!, n = params['number']!;
      return respond(('$w-$n', w, n));
    });
    handle = r.call;
  } else {
    final r = rouxRouter();
    handle = (req) async =>
        respond(readRoux(r.find('/${req.url.path}', method: req.method)));
  }
  shelf.Request request(String p) =>
      shelf.Request('GET', Uri.parse('http://localhost$p'));
  for (final e in samples.entries) {
    final res = await handle(request(e.key));
    if (res.context['parts'] != e.value ||
        res.statusCode != (e.value == null ? 404 : 200)) {
      throw StateError('$target ${e.key}');
    }
  }
  final req = request(path);
  const n = 8192;
  final times = <double>[];
  var sum = 0;
  for (var round = 0; round < 8; round++) {
    final sw = Stopwatch()..start();
    for (var i = 0; i < n; i++)
      sum += consume((await handle(req)).context['parts'] as Parts?);
    sw.stop();
    if (round != 0) times.add(ns(sw, n));
  }
  finish(times, sum);
}

Future<void> main(List<String> args) async {
  final target = args.single;
  if (target == 'shelf' || target == 'roux-shelf') {
    await dispatch(target);
  } else {
    pure(target);
  }
}
