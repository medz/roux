import 'package:roux/roux.dart';

void main() {
  final router = Router<int>();
  router.add(r'/nested/:id(([A-Za-z]+)-(\d+))', 1);
  for (var i = 1; i <= 32; i++) {
    router.add('/same/:id([0-9]{$i})', i);
  }
  for (final (name, path) in [
    ('nested', '/nested/Report-42'),
    ('no-prefix-last', '/same/${'4' * 32}'),
  ]) {
    final timings = <double>[];
    var checksum = 0;
    for (var r = 0; r < 8; r++) {
      const n = 65536;
      final t = Stopwatch()..start();
      for (var i = 0; i < n; i++) {
        final m = router.find(path, method: 'GET')!;
        checksum += m.data + m.params['id']!.length + (m.params['0']?.length ?? 0) + (m.params['1']?.length ?? 0);
      }
      t.stop();
      if (r != 0) timings.add(1e9 * t.elapsedTicks / t.frequency / n);
    }
    timings.sort();
    print('$name ${timings[3].toStringAsFixed(1)} $checksum');
  }
}
