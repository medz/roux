import 'package:roux/roux.dart';

void main() {
  final router = Router<int>();
  router.add('/ping', 1);
  router.add('/users/:id', 2);
  router.add(r'/rx/:id(\d+)', 3);
  router.add(r'/media/:id.:ext', 4);
  router.add(r'/area/:lang(en|fr)/:id(\d+)', 5);
  for (var i = 0; i < 32; i++) {
    router.add('/many/:id(v${i}_' r'\d+)', i + 10);
  }
  for (final (name, paths) in [
    ('static', ['/ping']),
    ('param', ['/users/42']),
    ('regex', ['/rx/42']),
    ('embedded', ['/media/report.pdf']),
    ('two-regex', ['/area/fr/42']),
    ('regex32-last', ['/many/v31_42']),
    ('rotating', List.generate(4096, (i) => '/users/$i')),
  ]) {
    const n = 131072;
    final samples = <double>[];
    var sum = 0;
    for (var r = 0; r < 8; r++) {
      final sw = Stopwatch()..start();
      for (var i = 0; i < n; i++) {
        final m = router.find(paths[i % paths.length], method: 'GET')!;
        sum += m.data + (m.params['id']?.length ?? 0);
      }
      sw.stop();
      if (r > 0) samples.add(1e9 * sw.elapsedTicks / sw.frequency / n);
    }
    samples.sort();
    print('$name ${samples[3].toStringAsFixed(1)} $sum');
  }
}
