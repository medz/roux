import 'package:roux/roux.dart' as roux;
import 'package:relic_core/relic_core.dart' as relic;
import 'package:shelf/shelf.dart' as shelf;
import 'package:shelf_router/shelf_router.dart' as sr;
import '../peerbuild.dart' as b;

Future<void> main(List<String> args) async {
  final target=args.single;
  for(final size in [128,8192]){
    final count=size==128?48:8, entries=List.generate(size,(i)=>b.entry(target,'params',i));
    final probes=[for(var i=0;i<count;i++) '/api/${(i*31+49)%size}/handoff/'];
    final patterns=[for(final p in probes) '$p${target=="shelf"?"<id>":":id"}'];
    final samples=<double>[];
    for(var n=0;n<24;n++){
      b.reset(target);
      final tables=[for(var j=0;j<count;j++)b.build(target,entries)];
      final clock=Stopwatch();
      if(target=='roux'){
        final rs=tables.cast<roux.Router<b.Handler>>();clock.start();
        for(var j=0;j<count;j++)rs[j].add(patterns[j],b.handler,method:'POST');
        clock.stop();
      } else if(target=='shelf'){
        final rs=tables.cast<sr.Router>();clock.start();
        for(var j=0;j<count;j++)rs[j].add('POST',patterns[j],b.handler);
        clock.stop();
      } else {
        final rs=tables.cast<relic.Router<b.Handler>>();clock.start();
        for(var j=0;j<count;j++)rs[j].add(relic.Method.post,patterns[j],b.handler);
        clock.stop();
      }
      for(var j=0;j<count;j++){
        final r=tables[j],p='${probes[j]}42';
        if(r is roux.Router<b.Handler>){
          if(r.find(p,method:'POST')?.data!=b.handler)throw StateError(p);
        } else if(r is relic.Router<b.Handler>) {
          if(r.lookup(relic.Method.post,p) is! relic.RouterMatch<b.Handler>)throw StateError(p);
        } else if((await (r as sr.Router)(shelf.Request('POST',Uri.parse('http://localhost$p')))).statusCode!=200){throw StateError(p);}
      }
      if(n>=3)samples.add(clock.elapsedTicks*1e9/clock.frequency/count);
    }
    samples.sort();print('batch-$size ${samples[samples.length~/2].toStringAsFixed(1)} 1');
  }
}
