import 'package:roux/roux.dart';

void main() {
  const n=512;
  final paths=[for(var i=0;i<n;i++) i.isEven ? '/api/items/$i' : '/api/$i/:id(v${i}_' r'\d+)'];
  final times=<double>[];
  var sum=0;
  for(var round=0;round<8;round++) {
    final t=Stopwatch();
    for(var rep=0;rep<32;rep++) {
      final r=Router<int>();
      t.start();
      for(var i=0;i<n;i++) r.add(paths[i],i,method:'GET');
      t.stop();
      sum+=r.find('/api/511/v511_42',method:'GET')!.data;
    }
    if(round!=0)times.add(t.elapsedTicks*1e9/t.frequency/(n*32));
  }
  times.sort();print('${times[3].toStringAsFixed(0)} ns/add checksum=$sum');
}
