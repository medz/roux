import 'package:roux/roux.dart';

void main() {
  final r = Router<int>()..add('/', 1)..add('/users/:id/orders/:order', 2, method: 'GET');
  final long = 'route' * 12;
  r.add('/directory/$long/:id', 3);
  final paths = <(String, String, String?)>[
    ('root', '/', null), ('empty', '', null),
    ('mixed-case method', '/Users/42/ORDERS/7', ' gEt '),
    ('long literal', '/directory/$long/12345', null),
  ];
  const n = 131072;
  for (final (name, path, method) in paths) {
    var check = 0;
    final times = <double>[];
    for (var round = 0; round < 8; round++) {
      final clock = Stopwatch()..start();
      for (var i = 0; i < n; i++) {
        final m = r.find(path, method: method)!;
        check += m.data + (m.params['id']?.length ?? 0);
      }
      clock.stop();
      if (round > 0) times.add(clock.elapsedTicks * 1e9 / clock.frequency / n);
    }
    times.sort();
    print('$name ${times[3].toStringAsFixed(1)} $check');
  }
}
