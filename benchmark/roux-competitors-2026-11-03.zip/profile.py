from pathlib import Path
import os,json,subprocess,sys,urllib.parse,urllib.request
r=Path(__file__).resolve().parent
dart=os.environ.get('DART', 'dart')
def read(proc):
 for line in proc.stdout:
  if line.startswith('@@'): return json.loads(line[2:])
  if 'error' in line.lower() or 'failed' in line.lower(): print(line.strip(),file=sys.stderr,flush=True)
 raise RuntimeError('VM stopped before sample, exit '+str(proc.wait()))
def run(stage,scenario,n,extra=()):
 args=[dart,'--suppress-analytics','run','--no-dds','--enable-vm-service=0/127.0.0.1','--packages='+str(r/(stage+'.json')),str(r/os.environ.get('ROUX_PROFILE_WORKER', 'profile_peer.dart' if extra else 'profile.dart')),scenario,str(n),*extra]
 proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 try:
  svc=read(proc)
  def rpc(name,**kw):
   u=svc['uri']+name+'?'+urllib.parse.urlencode({'isolateId':svc['isolate'],**kw})
   with urllib.request.urlopen(u,timeout=45) as f: reply=json.load(f)
   if 'error' in reply: raise RuntimeError(reply['error'])
   return reply['result']
  def stats():
   prof=rpc('getAllocationProfile',gc='true')
   return prof['memoryUsage']['heapUsage'],{c['class']['name']:(c.get('instancesCurrent',0),c.get('bytesCurrent',0)) for c in prof['members']}
  pre,classes=stats()
  proc.stdin.write('construct\n');proc.stdin.flush()
  obj=read(proc)['object']
  post,now=stats()
  live=int(rpc('_getRetainedSize',targetId=obj)['valueAsString'])
  delta=sorted([(k,i-classes.get(k,(0,0))[0],v-classes.get(k,(0,0))[1]) for k,(i,v) in now.items()],key=lambda x:x[2],reverse=True)
  proc.stdin.write('check\n');proc.stdin.flush()
  if proc.wait(timeout=15)!=0: raise RuntimeError('route check failed')
  return dict(stage=stage,case=scenario,n=n,retained=live,heapGrowth=post-pre,top=delta[:14])
 finally:
  if proc.poll() is None:proc.kill();proc.wait()
if __name__=='__main__':
 print(json.dumps(run(sys.argv[1],sys.argv[2],int(sys.argv[3]),sys.argv[4:])),flush=True)
