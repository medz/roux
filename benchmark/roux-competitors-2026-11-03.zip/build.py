from pathlib import Path
import os,sys,json,subprocess
r=Path(__file__).resolve().parent; work=r
dart=os.environ.get('DART', 'dart')
peer=r/'peers'; orig=peer/'.dart_tool/package_config.json'
def build(stage,benches):
 c=json.loads(orig.read_text())
 for p in c['packages']:
  from urllib.parse import urljoin
  p['rootUri']=urljoin(orig.as_uri(),p['rootUri'])
  if p['name']=='roux': p['rootUri']=(r.as_uri() if stage=='base' else (r/stage).as_uri() if (r/stage/'lib').exists() else work.as_uri())+'/'
 cfg=r/(stage+'.json');cfg.write_text(json.dumps(c))
 for bench in benches:
  path={'registration':work/'benchmark/registration.dart','lookup':work/'benchmark/lookup.dart','peers':peer/'peers.dart','peerbuild':r/'peerbuild.dart','prefixes':r/'prefixes.dart','tails':r/'tails.dart','remove':r/'remove.dart','cold':r/'cold.dart'}.get(bench,peer/(bench+'.dart'))
  subprocess.run([dart,'--suppress-analytics','compile','exe','--packages='+str(cfg),str(path),'-o',str(r/(stage+'-'+bench))],check=True,stdout=subprocess.DEVNULL)
if __name__=='__main__':build(sys.argv[1],sys.argv[2:])
