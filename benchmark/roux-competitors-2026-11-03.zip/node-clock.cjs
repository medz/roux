// dart2js selects the high-resolution clock when window.performance is present.
globalThis.window = { performance: globalThis.performance };
require('./node-args.cjs');
