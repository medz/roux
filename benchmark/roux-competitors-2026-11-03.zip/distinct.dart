import 'package:relic_core/relic_core.dart' as relic;
import 'package:roux/roux.dart' as roux;
import 'package:shelf/shelf.dart' as shelf;
import 'package:shelf_router/shelf_router.dart' as sr;
import 'peerbuild.dart' as b;

Object build(String target, String kind,int n) {
  final Object table = target=='roux' ? roux.Router<b.Handler>() : target=='shelf' ? sr.Router() : relic.Router<b.Handler>();
  for(var i=0;i<n;i++){
    final e=b.entry(target,kind,i), id=i;
    shelf.Response handler(shelf.Request req)=>shelf.Response.ok('',context:{'id':id});
    if(table is roux.Router<b.Handler>) { table.add(e.pattern,handler,method:e.method); }
    else if (table is relic.Router<b.Handler>) { table.add(e.relicMethod,e.pattern,handler); }
    else { (table as sr.Router).add(e.method,e.pattern,handler); }
  }
  return table;
}

Future<void> check(Object table,String kind,int n) async {
  for(final i in [0,1,n~/2,n-1]) {
    final e=b.route(kind,i), req=shelf.Request(e.method,Uri.parse('http://localhost${e.probe}'));
    final shelf.Response res;
    if(table is roux.Router<b.Handler>) {
      res=table.find(e.probe,method:e.method)!.data(req);
    } else if(table is relic.Router<b.Handler>) {
      final hit=table.lookup(b.entry('roux',kind,i).relicMethod,e.probe) as relic.RouterMatch<b.Handler>;
      res=hit.value(req);
    } else {
      res=await (table as sr.Router)(req);
    }
    if(res.context['id']!=i) throw StateError('$i ${e.probe} ${res.context}');
  }
}
