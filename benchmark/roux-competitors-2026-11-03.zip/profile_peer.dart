import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:isolate';
import 'peerbuild.dart' as b;
import 'distinct.dart' as d;

Future<void> main(List<String> args) async {
  final kind = args[0], n = int.parse(args[1]);
  final control = StreamIterator(stdin.transform(utf8.decoder).transform(const LineSplitter()));
  final info = await Service.getInfo();
  print('@@${jsonEncode({'uri': info.serverUri.toString(), 'isolate': Service.getIsolateId(Isolate.current)})}');
  await control.moveNext();
  b.reset(args[2]);
  final distinct=args.length>3;
  final router = distinct ? d.build(args[2],kind,n) : b.build(args[2],Iterable.generate(n,(i)=>b.entry(args[2],kind,i)));
  print('@@${jsonEncode({'object':Service.getObjectId(router)})}');
  await control.moveNext();
  if(distinct){await d.check(router,kind,n);}else{await b.check(router, kind, n);}
  await control.cancel();
  exit(0);
}
