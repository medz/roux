import 'package:roux/roux.dart';

void main() {
  for (final width in [2, 4, 5, 32]) {
    final router = Router<int>();
    final paths = <String>[];
    for (var i = 0; i < 32; i++) {
      final prefix = '${'a' * (width - 2)}${i.toRadixString(36).padLeft(2, '0')}';
      router.add('/p/:id($prefix' r'\d+)', i);
      paths.add('/p/${prefix}42');
    }
    for (var i = 0; i < paths.length; i++) {
      if (router.find(paths[i])?.data != i) throw StateError(paths[i]);
    }
    final samples = <double>[];
    var checksum = 0;
    const n = 32768;
    for (var j = 0; j < 8; j++) {
      final watch = Stopwatch()..start();
      for (var i = 0; i < n; i++) {
        checksum += router.find(paths[i % paths.length])!.data;
      }
      watch.stop();
      if (j > 0) samples.add(watch.elapsedTicks * 1e9 / watch.frequency / n);
    }
    samples.sort();
    print('prefix-$width ${samples[3].toStringAsFixed(1)} $checksum');
  }
}
