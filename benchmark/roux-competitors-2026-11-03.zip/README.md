# Roux registration and lookup study

The three implementations use identical public lookup and registration workloads. The released Roux 2.0.0 is in lib/, the pre-change commit e47c912 is in checkpoint/lib/ and the tested candidate is in research/lib/. report.md contains the peer scorecard and both Roux comparisons. Per-process measurements, GC samples, unit-test logs and source hashes are in results/.

On macOS 27.2 arm64 the study used Dart 3.13.7, Node 26.11.1 and Python 3. From the extracted directory run these commands in sequence.

```sh
(cd research && dart pub get --enforce-lockfile && dart analyze --fatal-infos && dart test && dart test -p node)
(cd peers && dart pub get --enforce-lockfile)
export DART="$(command -v dart)"
mv results recorded-results
sh formal.sh
python3 mem_matrix.py
python3 peer_report.py
```

Allow loopback connections for retained heap and Node tests. Timings run in one process at a time. The single-add probe clocks one POST registration after 128 or 8,192 existing GET routes. The batch cross-check registers a different path in each prebuilt router. All fixture preparation and verification are outside those timers. The retained heap matrix covers shared handlers, independent closures and the last surviving registration after deletion.
