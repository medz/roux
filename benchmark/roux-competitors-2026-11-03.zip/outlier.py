from measure import run,r
targets=['base','checkpoint','research','relic','relic-nocache','shelf']
for exe,group,rounds in [('outlier','late-add',11),('batch','late-batch',7)]:
 run(group,{v:[r/((v if v in ('base','checkpoint') else 'research')+'-'+exe),'roux' if v in ('base','checkpoint','research') else v] for v in targets},rounds)
