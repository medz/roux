import 'dart:math';
import 'package:roux/roux.dart';
import 'benchmark/registration.dart' as b;
void main(){
 const n=4096;
 final order=List.generate(n,(i)=>i)..shuffle(Random(7001));
 for(final kind in ['static','params','nested','fallback','duplicate-all','many-methods']){
  final paths=List.generate(n,(i)=> switch(kind){
     'fallback'=>(pattern:'/a/$i/:v((?=a)(a|ab)(b+))',probe:'/a/$i/abbb',method:'GET'),
     'duplicate-all'=>(pattern:'/d/${i~/16}/:v',probe:'/d/${i~/16}/42',method:'GET'),
     'many-methods'=>(pattern:'/m/${i~/128}',probe:'/m/${i~/128}',method:'V${i%128}'),
     _=>b.registration(kind,i),
  });
  final times=<double>[];var checksum=0;
  for(var round=0;round<8;round++){
   final r=b.buildTable(paths);
   final t=Stopwatch()..start();
   for(final i in order){
    final p=paths[i];
    if(kind=='duplicate-all'){
     final all=r.findAll(p.probe,method:p.method);
     if(all.length!=16||all.first.data!=i~/16*16)throw StateError(kind);
     for(final m in all)checksum+=m.data+m.params['v']!.length;
    }else{
     final match=r.find(p.probe,method:p.method)!;
     if(match.data!=i)throw StateError(kind);
     checksum+=match.data+(match.params['id']?.length??0)+(match.params['0']?.length??0);
    }
   }
   t.stop();if(round>0)times.add(t.elapsedTicks*1e9/t.frequency/n);
  }
  times.sort();print('$kind ${times[3].toStringAsFixed(1)} $checksum');
 }
}
