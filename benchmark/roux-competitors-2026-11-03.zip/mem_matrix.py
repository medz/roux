from pathlib import Path
import json,sys,os
from profile import run
r=Path(__file__).resolve().parent;out=r/'results';out.mkdir(exist_ok=True)
with (out/'memory.jsonl').open('w') as f:
 for passno in range(3):
  keys=['base','checkpoint','research'] if passno%2==0 else ['research','checkpoint','base']
  for kind in ['static','params','wildcard','nested','indexed','methods','optional']:
   for key in keys:
    d=run(key,kind,8192);d.update(suite='retained',run=passno+1);f.write(json.dumps(d)+'\n');f.flush()
  for kind in ['static','params','methods','mixed','heads','deep','opaque']:
   variants=['base','checkpoint','research','relic','relic-nocache','shelf'];variants=variants[passno:]+variants[:passno]
   for version in variants:
    target='roux' if version in ['base','checkpoint','research'] else version
    d=run(version if version in ('base','checkpoint') else 'research',kind,8192,[target]);d.update(suite='peer',version=version,run=passno+1);f.write(json.dumps(d)+'\n');f.flush()
  for kind in ['static','params','methods']:
   for version in ['base','checkpoint','research','relic','relic-nocache','shelf']:
    target='roux' if version in ['base','checkpoint','research'] else version
    d=run(version if version in ('base','checkpoint') else 'research',kind,8192,[target,'distinct']);d.update(suite='distinct',version=version,run=passno+1);f.write(json.dumps(d)+'\n');f.flush()
  os.environ['ROUX_PROFILE_WORKER']='profile_after.dart'
  for v in keys:
   d=run(v,'static',8192);d.update(suite='removed',run=passno+1);f.write(json.dumps(d)+'\n');f.flush()
  del os.environ['ROUX_PROFILE_WORKER']
  print('memory pass',passno+1,'complete',flush=True)
