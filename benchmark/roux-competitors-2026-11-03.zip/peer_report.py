from pathlib import Path
import json,statistics,collections
r=Path(__file__).resolve().parent;out=r/'results'
read=lambda name: json.loads((out/name).read_text())
d=read('summary.json'); st=read('stability.json'); scale=read('scale.json')
m=[json.loads(x) for x in (out/'memory.jsonl').read_text().splitlines()]
ps=['relic','relic-nocache','shelf']; lab={'relic':'Relic','relic-nocache':'Relic NoCache','shelf':'shelf_router'}
kinds=['static','params','methods','mixed','heads','deep','opaque']; internal=['static','params','methods','wildcard','nested','indexed','optional']
label={'static':'Static','params':'Two parameters','methods':'Four methods','mixed':'Mixed structures','heads':'Distinct first segments','deep':'Deep static','opaque':'Long opaque parameter-table keys'}
lines=[];line=lines.append;counts=collections.defaultdict(list)
def section(s):line('');line('## '+s);line('')
def table(cols):line('| '+' | '.join(cols)+' |');line('| --- |'+' ---: |'*(len(cols)-1))
def row(values):line('| '+' | '.join(map(str,values))+' |')
def med(g,k):return d[g]['median'][k]
def heap(g,k):
 v=collections.defaultdict(list)
 for x in m:
  if x['suite']==g and x['case']==k:v[x.get('version',x['stage'])].append(x['retained']/x['n'])
 return {p:statistics.median(z) for p,z in v.items()}
def metric(name,values,group,peers=ps,our='research',unit=1,digits=1):
 x=values[our]/unit;cells=[name,f'{x:,.{digits}f}']
 for p in peers:
  y=values[p]/unit;ratio=y/x
  cells.append(f'{y:,.{digits}f} ({ratio:.2f}×)');counts[p].append((group+' / '+name,ratio))
 row(cells)
line('# Roux against Relic and shelf_router')
line('')
line('Measured 2026-11-03 on macOS 27.2 arm64 with Dart 3.13.7, Relic Core 1.2.0 and shelf_router 1.1.5 with Shelf 1.4.3. Every multiplier divides the peer’s time or memory by Roux’s. A value of 2× means Roux used half as much. A value below 1× means the peer won.')
cols=['Table','Roux']+[lab[p] for p in ps]
section('Registration time (ns per route)')
line('All peer configurations use the same candidate AOT executable for a given fixture. Each process registered 4,096 pregenerated routes with a shared handler. The result is the median of five fresh processes with rotating run order. Each process used one warmup and seven timed builds. The mixed table interleaves three parameter structures and a static route under the same first segment. The distinct-head table changes the first segment on every route. The opaque-key table uses nonnumeric service names of at least 25 characters. Shelf also registers HEAD for GET.');line('');table(cols)
for k in kinds:metric(label[k],med('peer-reg-'+k,'add'),'Registration')
line('');line('Late registration adds one differently shaped POST route to an existing two-parameter table. The single-add probe reports medians of 35 additions in each of eleven fresh processes. The seven-process batch cross-check times one addition on each of 48 independent routers at size 128, or eight at size 8,192. It uses a distinct path per router. Table construction and verification are outside both timers. The single-add rows count toward the score. All timings are ns per added route.');line('')
table(['Probe / existing routes','Checkpoint e47c912','Roux','Relic','Relic NoCache','shelf_router','Roux wins vs NoCache'])
for g,prefix,tag in [('late-add','outlier','Single'),('late-batch','batch','Batch')]:
 for n in (128,8192):
  key=f'{prefix}-{n}';vs=med(g,key);samples=d[g]['samples'];our=vs['research']
  wins=sum(a<b for a,b in zip(samples['research'][key],samples['relic-nocache'][key]))
  cells=[f'{tag} / {n:,}',f"{vs['checkpoint']:,.1f}",f'{our:,.1f}']
  for peer in ps:
   val=vs[peer];ratio=val/our;cells.append(f'{val:,.1f} ({ratio:.2f}×)')
   if g=='late-add':counts[peer].append((f'Late registration / {n:,}',ratio))
  row([*cells,f"{wins}/{len(samples['research'][key])}"])
section('Retained router heap (bytes per route)')
line('Median of three Dart VM retained-size measurements after forced GC at 8,192 registrations. Each entry in the first table references one shared handler. Objects also retained by Relic’s global path interner are excluded from its exclusive size.');line('');table(cols)
for k in kinds:metric(label[k],heap('peer',k),'Retained common handler')
line('');line('Each entry below owns a distinct closure that returns its route ID. The probes verify the selected ID, including different methods on one path.');line('');table(cols)
for k in ('static','params','methods'):metric(label[k],heap('distinct',k),'Retained distinct handlers')
section('Peak process RSS (MiB)')
line('Each fresh AOT process constructs 32,768 routes, including incremental input generation. RSS includes the runtime, allocator, transient allocations and router. Each populated row is the median of three processes.');line('');table(cols)
for k in kinds:metric(label[k],med('peer-rss-'+k,'peak'),'Peak RSS',unit=1048576,digits=2)
empty=med('peer-empty','peak')
line('');line('The zero-route process control measured '+', '.join(f'{name} {empty[p]/1048576:.2f} MiB' for name,p in [('Roux 2.0.0','base'),('Roux research','research'),*[(lab[v],v) for v in ps]])+'. It is excluded from the workload count.')
section('Pure lookup (ns per request)')
line('The shuffled workload has 256 static and 256 two-parameter GET routes. The endpoint and both captured values are checked before timing. Relic’s default path interner holds 10,000 keys. Its 4,096-key working set fits and its 32,768-key working set exceeds capacity. Both use the same steady-state query schedule. The nested fixture checks the full capture and both groups. Relic uses a handler-side regex to produce equivalent results.');line('');table(['Workload','Roux','Relic','Relic NoCache'])
for k,vs in d['competitor-research-pure']['median'].items():metric(k,vs,'Pure lookup',ps[:2],'roux')
metric('Nested regex',med('competitor-research-nested-pure','nested-hot'),'Pure lookup',ps[:2],'roux')
section('Shelf HTTP dispatch (ns per request)')
line('Both sides dispatch the same pregenerated Shelf requests and construct equivalent responses. The timer includes the async call and inspection of the payload.');line('');table(['Workload','Roux + Shelf','shelf_router'])
for k,vs in d['competitor-research-dispatch']['median'].items():metric(k,vs,'HTTP dispatch',['shelf'],'roux-shelf')
metric('Nested regex',med('competitor-research-nested-dispatch','nested-hot'),'HTTP dispatch',['shelf'],'roux-shelf')
section('10× target')
table(['Comparator','At least 10×','At least 1× and below 10×','Below 1×','Total'])
allp=[]
for p,ls in counts.items():
 f=[x[1] for x in ls];row([lab[p],sum(v>=10 for v in f),sum(1<=v<10 for v in f),sum(v<1 for v in f),len(f)])
 allp.extend((p,k,v) for k,v in ls)
line('');line('Each cell represents one workload, metric and peer configuration. Cells receive equal weight. Time and memory are scored separately.')
loss=[(p,k,v) for p,k,v in allp if v<1]
if loss:line('');line('Measured losses were '+', '.join(f'{lab[p]} on {k} ({v:.2f}×)' for p,k,v in loss)+'.')
floor=min(allp,key=lambda t:t[2])
line('');line(f'The smallest peer-to-Roux ratio was {floor[2]:.2f}× against {lab[floor[0]]} on {floor[1]}.')
limit=med('peer-rss-methods','peak')['relic-nocache']/1048576
line('');line(f'At the four-method peak RSS of {limit:.2f} MiB for Relic NoCache, a 10× result would require Roux to stay within {limit/10:.2f} MiB. This Roux AOT executable measured {empty["research"]/1048576:.2f} MiB with zero registrations.')
section('Regression gate against Roux 2.0.0')
line('The release snapshot is aec52fa. Native AOT timings use five initial process pairs. Dart JIT and dart2js on Node 26.11.1 use three. The public AOT lookup and Node registration suites always receive six and two additional pairs, respectively. Other initially slower lookup suites receive the same runtime-specific follow-up. All cases in repeated suites use pooled medians. The table shows the two preselected checks and any case with a slower initial or pooled median. A positive paired delta means Roux took longer.');line('')
shown=[z for z in st if z['first']['research']>z['first']['base'] or z['median']['research']>z['median']['base'] or (z['suite'],z['case']) in [('lookup','regex32'),('js-registration','wildcard')]]
if shown:
 table(['Suite / case','Pairs','2.0.0','Research','Paired delta','Slower pairs'])
 for z in shown:row([z['suite']+' / '+z['case'],z['count'],f"{z['median']['base']:.1f}",f"{z['median']['research']:.1f}",f"{z['pairedMedian']:+.1f}",z['slowerPairs']])
scope=['lookup','hot','captures','peers-lookup','peers-dispatch','nested','nested-dispatch','reversed','extra','legacy-registration','cold','remove','tails','prefixes','js-lookup','jit-lookup','js-registration','jit-registration','late-add']+['reg-'+k for k in internal]+['rss-'+k for k in internal]+['peer-reg-'+k for k in kinds]+['peer-rss-'+k for k in kinds]
flag={(z['suite'],z['case']):z for z in st};slows=[];total=0
def gate(g,k,b,v):
 global total
 total+=1
 if v>b:slows.append((g,k,b,v))
for g in scope:
 for k,v in d[g]['median'].items():
  z=flag.get((g,k));v=z['median'] if z else v
  gate(g,k,v['base'],v['research'])
for group,ks in [('retained',internal),('peer',kinds),('distinct',['static','params','methods'])]:
 for k in ks:
  vs=heap(group,k);gate(group,k,vs['base'],vs['research'])
removed={v:statistics.median([x['retained'] for x in m if x['suite']=='removed' and x['stage']==v]) for v in ['base','research']}
gate('Retained after removal','one survivor',removed['base'],removed['research'])
for n,vs in scale.items():gate('RSS scale',n,statistics.median(vs['base']),statistics.median(vs['research']))
line('');line(f'The release gate covers {total} timing and memory cells, including the parameter-table RSS sweep from 4,096 to 131,072 routes. '+(f'The number of pooled medians above the release was {len(slows)}.' if slows else 'All pooled medians were at or below the release.'))
if slows:
 line('');table(['Higher median','2.0.0','Research','Change'])
 for g,k,b,v in slows:row([g+' / '+k,f'{b:,.1f}',f'{v:,.1f}',f'+{100*(v/b-1):.2f}%'])
line('');line('All 70 unit tests pass on the VM and Node.js. The VM and compiled JavaScript each agreed with the release on 887,521 differential comparisons. The 53,568 new comparisons cover shared shapes, broad overlaps, registration of a different shape and removal at several positions of the varying literal.')
line('');line(f'After removing 8,191 of 8,192 static registrations, the surviving router retained {removed["research"]:,.0f} bytes. The release retained {removed["base"]:,.0f} bytes.')
line('');line('The Node clock resolves to 244.1 ns per route in the 4,096-route registration probe. Two larger runs of the same wildcard registration fixture give finer time resolution. Each row is a median of five processes. They are reported separately from the 157-cell release gate.');line('')
table(['Node wildcard registrations','2.0.0','Checkpoint','Roux','Change vs 2.0.0'])
for n in [16384,32768]:
 vals=med('node-wildcard-'+str(n),'wildcard');row([f'{n:,}',*[f'{vals[k]:,.1f}' for k in ['base','checkpoint','research']],f"{100*(vals['research']/vals['base']-1):+.2f}%"])
line('');line('A separate seven-process run at 4,096 routes uses Node’s performance.now through dart2js’s window.performance clock adapter. The router and Dart benchmark sources are identical. This diagnostic does not replace the original Node readings.');line('')
table(['High-resolution Node registration','2.0.0','Checkpoint','Roux','Change vs 2.0.0'])
for k,vals in d['node-precise-registration']['median'].items():
 row([k,*[f'{vals[v]:,.1f}' for v in ['base','checkpoint','research']],f"{100*(vals['research']/vals['base']-1):+.2f}%"])
section('Checkpoint comparison')
line('Same-machine measurements against the pre-change commit e47c912. Timings are in ns per operation. Retained heap is in bytes per route and peak process RSS is in MiB. The complete before/after samples for every measured checkpoint cell are in the bundle.');line('')
table(['Workload','Checkpoint','Roux','Change'])
cp=[]
for g,suite in d.items():
 if not (g.startswith(('checkpoint-','peer-reg-','peer-rss-')) or g in ('late-add','late-batch')): continue
 for k,vs in suite['median'].items():
  if 'checkpoint' not in vs:continue
  factor=1048576 if g.startswith('peer-rss-') else 1
  cp.append((g+' / '+k,vs['checkpoint']/factor,vs['research']/factor))
for group,ks in [('retained',internal),('peer',kinds),('distinct',['static','params','methods'])]:
 for k in ks:
  vals=heap(group,k);cp.append((group+' / '+k,vals['checkpoint'],vals['research']))
for g,b,a in cp:
 if (g.startswith('peer-reg-') or g in ('checkpoint-public / regex32','checkpoint-public / hot /nested/Report-42','peer / params','peer / mixed','peer-rss-params / peak')):
  row([g,f'{b:,.1f}',f'{a:,.1f}',f'{100*(a/b-1):+.2f}%'])
above=[(g,b,a) for g,b,a in cp if a>b]
line('');line(f'{len(above)} of these {len(cp)} checkpoint medians increased. The following list includes every increase of at least 5%. Smaller changes and the complete raw samples are in results/summary.json and results/memory.jsonl. The 5% cutoff is used only to shorten this list. The release gate above counts every increase.')
large=[(g,b,a) for g,b,a in above if a/b>=1.05]
if large:
 line('');table(['Candidate at least 5% above checkpoint','Checkpoint','Roux','Change'])
 for g,b,a in large:row([g,f'{b:,.1f}',f'{a:,.1f}',f'{100*(a/b-1):+.2f}%'])
section('Implementation size')
liblines=lambda folder: sum(len(p.read_text().splitlines()) for p in folder.rglob('*.dart'))
size=liblines(r/'research/lib'); old=liblines(r/'lib'); checkpoint=liblines(r/'checkpoint/lib')
line('Literal routes hold payloads directly. Parameter routes with a common shape share their capture names and keep one handler row per differing segment. When a new shape overlaps, the trie expands only that row.');line('')
line(f'The candidate contains {size:,} physical Dart source lines under lib/. The checkpoint has {checkpoint:,} ({size-checkpoint:+,} lines in the candidate) and the release has {old:,}. The shared branch uses the existing single-child store and allocates a sibling map only when it needs a second concrete child. Registration and removal reuse the literal prefix they already decoded. A route with one capture stores its key and position directly. Routes with multiple captures store the gaps between keys. Row maps compact when deletions bring them down to a quarter of their earlier size. The regex index hashes only the variable portion of a common prefix, retaining registration order for collisions and checking the complete regex before accepting a result.')
section('Reproduction')
line('The in-repository peer package reproduces the standard registration, peak RSS, shuffled lookup and HTTP dispatch workloads. It has its own dependency lockfile.');line('');line(chr(96)*3+'sh')
line('cd benchmark/peers && dart pub get --enforce-lockfile')
line('dart compile exe registration.dart -o /tmp/roux-peer-register')
line('dart compile exe lookup.dart -o /tmp/roux-peer-lookup')
line('dart compile exe late_registration.dart -o /tmp/roux-late-register')
line('for r in roux relic relic-nocache shelf; do /tmp/roux-late-register "$r"; done')
line('for r in roux relic relic-nocache shelf; do /tmp/roux-peer-register "$r" params 4096; done')
line('for r in roux relic relic-nocache shelf; do /tmp/roux-peer-register "$r" methods 32768 rss; done')
line('for r in roux relic relic-nocache roux-shelf shelf; do /tmp/roux-peer-lookup "$r"; done')
line(chr(96)*3);line('')
line('The accompanying study bundle contains release, checkpoint and candidate sources, the peer lockfile, fixtures, drivers and per-process measurements. From its extracted directory, run the following commands in sequence.');line('');line(chr(96)*3+'sh')
line('(cd peers && dart pub get --enforce-lockfile)');line('export DART="$(command -v dart)"')
line('mv results recorded-results');line('sh formal.sh');line('python3 mem_matrix.py');line('python3 peer_report.py');line(chr(96)*3)
line('');line('The retained-size diagnostic uses a loopback VM-service port. The public lookup fixture is unchanged. The HTTP timings exclude socket transport.')
count10=sum(v>=10 for _,_,v in allp)
lines[3:3]=['',f'Of {len(allp)} peer comparisons, {count10} reached 10×, {len(allp)-count10-len(loss)} reached parity but fell short of 10×, and {len(loss)} fell below parity. Roux exceeded the release median in {len(slows)} of {total} timing and memory cells.']
probe=med('node-precise-registration','wildcard')
lines[4]+=f" The separate high-resolution Node wildcard registration probe measured {probe['research']:.1f} ns/route versus {probe['base']:.1f} in 2.0.0 ({100*(probe['research']/probe['base']-1):+.2f}%)."
(r/'report.md').write_text('\n'.join(lines)+'\n')
(out/'score.json').write_text(json.dumps(dict(comparisons=len(allp),atLeast10=sum(v>=10 for _,_,v in allp),below1=loss,regressionCells=total,higherMedians=slows,checkpointCells=len(cp),checkpointHigher=above,smallestPeerRatio=floor),indent=2)+'\n')
