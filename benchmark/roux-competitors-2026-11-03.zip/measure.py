from pathlib import Path
import json,subprocess,re,statistics,sys,os
r=Path(__file__).resolve().parent
out=r/'results';out.mkdir(exist_ok=True)
cases=['static','params','wildcard','nested','indexed','methods','optional']
def parse(line):
 if ' ns/add' in line and ' routes: ' in line:
  return line.split()[0],float(line.split(': ')[1].split()[0]),''
 if 'peak RSS ' in line:
  m=re.search(r'peak RSS (\d+) bytes, growth (\d+) bytes',line)
  return 'peak',int(m[1]),''
 if 'ns/op' in line:
  m=re.fullmatch(r'(.+?)\s+([\d.]+) ns/op\s+checksum=(-?\d+)',line)
  return m[1],float(m[2]),m[3]
 if ' ns/add' in line:return 'add',float(line.split()[0]),line.split('checksum=')[1]
 if ' routes:' in line:raise ValueError(line)
 if re.match(r'^(roux|shelf|relic|relic-nocache) ',line):return ('peak' if len(line.split())==5 else 'add'),float(line.split()[-1]),''
 name,t,c=line.rsplit(' ',2)
 if name in ['ascending','descending','random','alternating','churn']:return name,float(c),''
 return name,float(t),c

def run(group,cmds,rounds):
 sample={k:{} for k in cmds}; sums={}
 for i in range(rounds):
  keys=list(cmds)
  order=(keys if i%2==0 else keys[::-1]) if len(keys)==2 else keys[i%len(keys):]+keys[:i%len(keys)]
  for key in order:
   raw=subprocess.check_output([str(x) for x in cmds[key]],text=True)
   (out/f'{group}-{key}-{i+1}.txt').write_text(raw)
   for line in raw.splitlines():
    name,t,c=parse(line); assert sums.setdefault(name,c)==c,(group,name,sums[name],c)
    sample[key].setdefault(name,[]).append(t)
 med={name:{key:statistics.median(values[name]) for key,values in sample.items()} for name in sums}
 all_data[group]={'median':med,'samples':sample}
 (out/'summary.json').write_text(json.dumps(all_data,indent=2)+'\n')
 print(group,json.dumps(med),flush=True)

p=out/'summary.json'
all_data=json.loads(p.read_text()) if p.exists() else {}
modes=sys.argv[1:] or ['lookup','registration','peers','rss']
def pair(exe,*args):return {v:[r/(v+'-'+exe),*args] for v in ['base','research']}
if __name__=='__main__':
 if 'lookup' in modes:
  for group,exe,args in [('lookup','lookup',[]),('hot','hot',[]),('captures','captures',[]),('peers-lookup','peers',['roux']),('peers-dispatch','peers',['roux-shelf']),('nested','nested',['roux']),('nested-dispatch','nested',['roux-shelf']),('reversed','reversed',['roux']),('extra','extra',[]),('legacy-registration','register',[]),('cold','cold',[]),('remove','remove',['8192']),('tails','tails',[]),('prefixes','prefixes',[])]:
   run(group,pair(exe,*args),5)
 if 'registration' in modes:
  for kind in cases:run('reg-'+kind,pair('registration',kind,'4096'),5)
 if 'peers' in modes:
  for kind in ['static','params','methods']:
   run('peer-reg-'+kind, {key:[r/((key if key in ('base','checkpoint') else 'research')+'-peerbuild'),'roux' if key in ['base','research','checkpoint'] else key,kind,'4096'] for key in ['base','checkpoint','research','relic','relic-nocache','shelf']},5)
 if 'rss' in modes:
  for kind in cases:run('rss-'+kind,pair('registration',kind,'32768','rss'),5)
  for kind in ['static','params','methods']:
   run('peer-rss-'+kind, {key:[r/((key if key in ('base','checkpoint') else 'research')+'-peerbuild'),'roux' if key in ['base','research','checkpoint'] else key,kind,'32768','rss'] for key in ['base','checkpoint','research','relic','relic-nocache','shelf']},3)
 if 'web' in modes:
  for kind in ['lookup','registration']:
   run('js-'+kind, {v:['node',r/(v+'-'+kind+'.js')] for v in ['base','research']},3)

 if 'jit' in modes:
  work=r
  dart=os.environ.get('DART', 'dart')
  for kind in ['lookup','registration']:
   run('jit-'+kind, {v:[dart,'--suppress-analytics','run','--packages='+str(r/(v+'.json')),work/'benchmark'/(kind+'.dart')] for v in ['base','research']},3)
