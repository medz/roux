import 'dart:convert';
import 'lib/roux.dart' as old;
import 'package:roux/roux.dart' as current;

void main() {
  var checks = 0;
  for (final sensitive in [false, true]) {
    final a = old.Router<int>(caseSensitive: sensitive);
    final b = current.Router<int>(caseSensitive: sensitive);
    final patterns = [
      r':x(\d+)', r':x([0-9]+)', r':x(v\d+)', r':x(AB[0-9]{2})', r':x(\d{0})',
      r':x(v\d{0})', r':x([a-z]{2})', r':x(\D{2})', r':x(.{2})', r':x([^a]{3})',
      r':x(a|b)', r':x(ab?c)', r':x(abc[XY]*)', r':x(([a-z]+)-(\d+))',
      r':x((?<letter>[a-z])\k<letter>(\d+))', r':x((a)?(b))', r':x(A(B(C)?))',
      r'((a|bc)(?:d)?)', r'([()])', r':x([a\]]{2})', r':x(\(a\))', r':one.:two',
      r':one@@:two', r':x(.*).:two', r':x.:y.:z', r'file-*-*.txt',
      r'foo*', r':x(a)tail', r'(a)-:name', r':x(\d+){-:y}?', r':a((x)(y))_:b((x)?)',
      r':x(AB[^0-9]{2})', r':x((?=\w)\w+)', r':x((?<=a)b)', r':x(A(?:B){1})',
    ];
    final buckets = [
      [r':x(abc\d+)',r':x(abcd\w+)',r':x(ab[0-9]+)',r':x(a.+)',r':fallback'],
      [r':x(.{1})',r':x([0-9]{2})',r':x(\D{2})',r':x([\s\S]{3})'],
      [r':x(ß\d+)',r':x(k\d+)',r':x(s\d+)',r':x(i\d+)'],
    ];
    final names = <String>[];
    for (var i=0;i<patterns.length+buckets.length;i++) {
      final prefix='p$i';
      names.add(prefix);
      final set=i<patterns.length?[patterns[i]]:buckets[i-patterns.length];
      for (var j=0;j<set.length;j++) {
        for (final method in [null,'GET']) {
          a.add('/$prefix/${set[j]}',i*100+j,method:method);
          b.add('/$prefix/${set[j]}',i*100+j,method:method);
        }
      }
    }
    final values = <String>{'', '42', '00', 'a.b.c.', '.abc', 'a..', 'ab.x.y', 'a@@b@@', 'AA42', 'Ab42','v00','v','a\nb','ab-42','Report-42','a42','abc01','ABCD42','abXYZ','ABcd','ABC', '🐈', 'K42', 'ſ42', 'ı42', 'İ42','[]','(a)','ab]','３', '\n', '42\n', 'aa42', 'xy_x', 'ALPHA-1', '00-', 'abc\u2028'};
    for(final x in ['a','1','.',']','*','-', 'Ä','0','\n','@']) {
      for(final y in ['a','b','1','.',']','*','-','@','0']) {
        for(final z in ['','a','.','0','@']) values.add('$x$y$z');
      }
    }
    for(final name in names) {
      for(final value in values) {
        final p='/$name/$value';
        for(final method in [null,'get','POST']) {
          final x=a.find(p,method:method), y=b.find(p,method:method);
          void cmp(Object? u, Object? v) {
            checks++;
            if(jsonEncode(u)!=jsonEncode(v)) throw StateError('$p $sensitive $method $u vs $v');
          }
          cmp(x==null?null:[x.data,x.params],y==null?null:[y.data,y.params]);
          for(final any in [true,false]) {
            cmp([for(final m in a.findAll(p,method:method,includeAny:any))[m.data,m.params]],
              [for(final m in b.findAll(p,method:method,includeAny:any))[m.data,m.params]]);
          }
        }
      }
    }
  }
  print('$checks pattern lookup results equal');
}
